# Unit Testing ObjectScript

## Setup

ISC's `%UnitTest` framework requires a full directory path to the where the test code lives in the file system.  This is configured through the `^UnitTestRoot` global.  For example, on a windows system:

```
Set gitRepo = "C:\gitprojects\cdr-cis-iris-hscustom-oci"
Set ^UnitTestRoot = gitRepo _ "\CVS\CDR\Tests"
```

Additionally, access through the system management portal has to be explicitly granted by setting this global:
```
Set $namespace="%SYS"
Set ^SYS("Security", "CSP", "AllowPrefix", 0, "%UnitTest.") = 1
```

## Organization
All test code lives within the `CVS.CDR.Tests.*` package.  From here, tests are grouped by dependency complexity with the idea that you run test suites in order of increasing dependency complexity:

- `Tests.Unit.*`: Tests against code for which there are zero dependencies.  (No relance on Database Records, system config, etc)
- `Tests.Model.*`: Unit tests + database dependencies.  Examples: saving records to test before/after insert/update/delete triggers, SQL queries, relationship integrety is maintained on update/delete.
- `Tests.Functional.*`: Unit or Model tests + system configuration.  Examples: validating System defaults.
- `Tests.Integration.*`: Functional + System setup or external system depenencies.  Examples: Rest APIs, Health Share productions, etc.


## Running Tests
Each test suite can be run in turn:
```
do ##class(%UnitTest.Manager).RunTest("Unit", "/nodelete")
;do ##class(%UnitTest.Manager).RunTest("Model", "/nodelete")
;do ##class(%UnitTest.Manager).RunTest("Functional", "/nodelete")
;do ##class(%UnitTest.Manager).RunTest("Integration", "/nodelete")
```

The first parameter to the RunTest method can also be a file path and contain multiple comma delimited paths and exclusion patterns:

```
do ##class(%UnitTest.Manager).RunTest("Unit\HS,Unit\FHIR", "/nodelete")
do ##class(%UnitTest.Manager).RunTest("Unit,-Unit\sub-folders", "/nodelete")
```

## Additional Reading
- [Unit Test Portal](https://docs.intersystems.com/iris20231/csp/docbook/Doc.View.cls?KEY=TUNT_ExampleTestPortal)
