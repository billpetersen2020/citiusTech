SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member)
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV')